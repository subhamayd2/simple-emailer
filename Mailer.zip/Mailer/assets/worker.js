var empIDs = [];
var selectedIDs = [];

var DataFile;
var DataModel = {
	message: '',
	ids: ''
};

window.addEventListener('load', function() {
	var _file = document.getElementById('file');
	var _filePath = document.getElementById('file-path');
	_filePath.addEventListener('click', function() { _file.click() });
	_file.addEventListener('change', function(e) { 
		DataFile = e.target.files[0];
		_filePath.value = DataFile['name'];
		renderUI();
	});
});

function renderUI() {
if(DataFile == null) {

}
	var reader = new FileReader();
	reader.onload = (function(theFile) {
        return function(e) {
          var data = e.target.result;
console.log(data);

	  DataModel.message = data.split('#')[0].replace(/\"/, "");
	  var idsString = data.split('#')[1].replace(/\"\,/, "");
	  DataModel.message = DataModel.message.replace(/\|\|/g, '\n');
console.log(idsString);
	  DataModel.ids = idsString.split(',').join(';');
	  document.getElementById('ids').value = DataModel.ids;
	  document.getElementById('msg').value = DataModel.message;
        };
      	})(DataFile);
	
	reader.readAsText(DataFile);
}

function openMail() {
	var subject = document.getElementById('subject').value;
	var ids = document.getElementById('ids').value;
	var msg = document.getElementById('msg').value;
	var cc = document.getElementById('cc').value;

	if(subject == '') {
		alert("Please provide a subject");
		return;
	}
	msg = msg.replace(/\|\|/g, '%0D%0A');
	msg = msg.replace(/\r\n|\r|\n/g, '%0D%0A');
	
	var mailStr = "mailto://" + ids + "?";
	mailStr += "subject=" + subject;
	mailStr += "&body=" + msg;
	if(cc != '') {
		mailStr += "&cc=" + cc;
	}

	var _a = document.createElement('a');
	_a.setAttribute('href', mailStr);
	_a.click();
}
